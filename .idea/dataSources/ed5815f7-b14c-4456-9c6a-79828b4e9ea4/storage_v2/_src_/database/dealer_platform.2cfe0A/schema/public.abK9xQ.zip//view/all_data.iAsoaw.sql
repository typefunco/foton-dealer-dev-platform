create view all_data
            (dealer_id, ruft, dealer_name_ru, dealer_name_en, region, city, manager, joint_decision, check_list_score,
             dealership_class, brands, branding, marketing_investments, by_side_businesses, dd_recommendation,
             stock_hdt, stock_mdt, stock_ldt, buyout_hdt, buyout_mdt, buyout_ldt, foton_sales_personnel,
             sales_target_plan, sales_target_fact, service_contracts_sales, sales_trainings, sales_recommendation,
             recommended_stock_pct, warranty_stock_pct, foton_labor_hours_pct, warranty_hours, service_contracts_hours,
             as_trainings, spare_parts_sales_q, spare_parts_sales_ytd_pct, as_recommendation, quantity_sold,
             sales_revenue, sales_margin, sales_margin_pct, sales_profit_pct, as_revenue, as_margin, as_margin_pct,
             as_profit_pct, period, updated_at)
as
SELECT d.dealer_id,
       d.ruft,
       d.dealer_name_ru,
       d.dealer_name_en,
       d.region,
       d.city,
       d.manager,
       d.joint_decision,
       dd.check_list_score,
       dd.dealership_class,
       dd.brands,
       dd.branding,
       dd.marketing_investments,
       dd.by_side_businesses,
       dd.dd_recommendation,
       s.stock_hdt,
       s.stock_mdt,
       s.stock_ldt,
       s.buyout_hdt,
       s.buyout_mdt,
       s.buyout_ldt,
       s.foton_sales_personnel,
       s.sales_target_plan,
       s.sales_target_fact,
       s.service_contracts_sales,
       s.sales_trainings,
       s.sales_recommendation,
       a.recommended_stock_pct,
       a.warranty_stock_pct,
       a.foton_labor_hours_pct,
       a.warranty_hours,
       a.service_contracts_hours,
       a.as_trainings,
       a.spare_parts_sales_q,
       a.spare_parts_sales_ytd_pct,
       a.as_recommendation,
       ps.quantity_sold,
       ps.sales_revenue,
       ps.sales_margin,
       ps.sales_margin_pct,
       ps.sales_profit_pct,
       pa.as_revenue,
       pa.as_margin,
       pa.as_margin_pct,
       pa.as_profit_pct,
       COALESCE(dd.period, s.period, a.period, ps.period, pa.period) AS period,
       d.updated_at
FROM dealers d
         LEFT JOIN dealer_development dd ON d.dealer_id = dd.dealer_id
         LEFT JOIN sales s ON d.dealer_id = s.dealer_id AND dd.period = s.period
         LEFT JOIN aftersales a ON d.dealer_id = a.dealer_id AND dd.period = a.period
         LEFT JOIN performance_sales ps ON d.dealer_id = ps.dealer_id AND dd.period = ps.period
         LEFT JOIN performance_aftersales pa ON d.dealer_id = pa.dealer_id AND dd.period = pa.period;

alter table all_data
    owner to postgres;

